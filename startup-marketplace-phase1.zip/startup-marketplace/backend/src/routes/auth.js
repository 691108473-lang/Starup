import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { z } from "zod";
import { query } from "../db/pool.js";

const router = Router();

const registerSchema = z.object({
  email: z.string().email(),
  username: z.string().min(3).max(80).optional(),
  password: z.string().min(8),
  name: z.string().min(1).max(160)
});

function signUser(user) {
  return jwt.sign(
    { sub: user.id, email: user.email, role: user.role, name: user.name },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || "1h" }
  );
}

router.post("/register", async (req, res, next) => {
  try {
    const data = registerSchema.parse(req.body);
    const exists = await query("SELECT id FROM users WHERE email = $1", [data.email]);

    if (exists.rowCount) {
      return res.status(409).json({
        success: false,
        error: { code: "EMAIL_EXISTS", message: "อีเมลนี้ถูกใช้งานแล้ว" }
      });
    }

    const hash = await bcrypt.hash(data.password, 12);
    const result = await query(
      `INSERT INTO users(email, username, password_hash, name)
       VALUES ($1,$2,$3,$4)
       RETURNING id,email,username,name,role`,
      [data.email, data.username ?? null, hash, data.name]
    );

    const user = result.rows[0];
    res.status(201).json({ success: true, data: { user, token: signUser(user) }, message: "สมัครสมาชิกสำเร็จ" });
  } catch (err) {
    next(err);
  }
});

router.post("/login", async (req, res, next) => {
  try {
    const schema = z.object({
      email: z.string().email(),
      password: z.string().min(1)
    });
    const data = schema.parse(req.body);
    const result = await query(
      "SELECT id,email,name,role,password_hash,is_active FROM users WHERE email=$1",
      [data.email]
    );

    if (!result.rowCount || !result.rows[0].is_active) {
      return res.status(401).json({
        success: false,
        error: { code: "INVALID_CREDENTIALS", message: "อีเมลหรือรหัสผ่านไม่ถูกต้อง" }
      });
    }

    const user = result.rows[0];
    const valid = await bcrypt.compare(data.password, user.password_hash || "");
    if (!valid) {
      return res.status(401).json({
        success: false,
        error: { code: "INVALID_CREDENTIALS", message: "อีเมลหรือรหัสผ่านไม่ถูกต้อง" }
      });
    }

    delete user.password_hash;
    res.json({ success: true, data: { user, token: signUser(user) }, message: "เข้าสู่ระบบสำเร็จ" });
  } catch (err) {
    next(err);
  }
});

// Google OAuth integration point.
// Add a verified OAuth library/provider before enabling this route in production.
router.get("/google", (req, res) => {
  res.status(501).json({
    success: false,
    error: {
      code: "GOOGLE_OAUTH_NOT_CONFIGURED",
      message: "Google Sign-In ต้องตั้งค่า OAuth Client ก่อนใช้งานจริง"
    }
  });
});

router.get("/google/callback", (req, res) => {
  res.status(501).json({
    success: false,
    error: {
      code: "GOOGLE_OAUTH_NOT_CONFIGURED",
      message: "Google OAuth callback ยังไม่ได้เชื่อม Provider"
    }
  });
});

export default router;
