# MarketHub — Full Stack Marketplace

## การเชื่อมต่อ
Frontend → REST API (Express) → PostgreSQL → Admin Dashboard

## ระบบที่มี
- สมัครสมาชิก / Login / JWT
- Google OAuth พร้อม callback (ต้องใส่ Google credentials)
- สินค้า + ค้นหา + หมวดหมู่
- Cart CRUD
- Checkout / Order transaction / stock deduction
- Tax 7% และค่าส่ง 60 บาทเมื่อยอดต่ำกว่า 1,500 บาท
- Order history
- Admin dashboard + users + products + orders + monthly sales
- Role: user / staff / admin / super_admin
- Helmet, CORS, Rate Limit, password hashing

## เริ่มใช้งาน
1. ติดตั้ง Docker Desktop
2. `docker compose up -d postgres`
3. `cd backend && npm install`
4. คัดลอก `.env.example` เป็น `.env` และตั้ง JWT_SECRET
5. `npm run db:init`
6. `npm run db:seed`
7. `npm run dev`
8. เปิด frontend ด้วย static server เช่น `npx serve frontend -l 5500`
9. เปิด admin ที่ `http://localhost:5500/admin/`

บัญชี Admin เริ่มต้น: `admin@markethub.local` / `ChangeMe123!` — เปลี่ยนทันทีเมื่อใช้งานจริง

## Google Sign-In
สร้าง OAuth 2.0 Client ใน Google Cloud แล้วใส่ `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` และ callback URL ให้ตรงกับ `.env`.
