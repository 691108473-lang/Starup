import jwt from 'jsonwebtoken';
export function signToken(user){return jwt.sign({sub:user.id,email:user.email,role:user.role,name:user.name},process.env.JWT_SECRET,{expiresIn:'7d'});}
export function requireAuth(req,res,next){try{const h=req.headers.authorization||''; if(!h.startsWith('Bearer ')) return res.status(401).json({success:false,error:{message:'กรุณาเข้าสู่ระบบ'}}); req.user=jwt.verify(h.slice(7),process.env.JWT_SECRET); next();}catch{return res.status(401).json({success:false,error:{message:'Token ไม่ถูกต้องหรือหมดอายุ'}})}}
export function requireRole(...roles){return (req,res,next)=>roles.includes(req.user?.role)?next():res.status(403).json({success:false,error:{message:'ไม่มีสิทธิ์เข้าถึง'}})}
