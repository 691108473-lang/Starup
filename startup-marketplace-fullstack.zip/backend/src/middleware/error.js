export function notFound(req,res){res.status(404).json({success:false,error:{message:'ไม่พบ API นี้'}})}
export function errorHandler(err,req,res,next){console.error(err);res.status(err.status||500).json({success:false,error:{message:err.message||'เกิดข้อผิดพลาดของเซิร์ฟเวอร์'}})}
