import 'dotenv/config'; import fs from 'node:fs'; import { pool } from './pool.js';
await pool.query(fs.readFileSync(new URL('./schema.sql', import.meta.url),'utf8')); console.log('Database initialized'); await pool.end();
