import 'dotenv/config'; import bcrypt from 'bcryptjs'; import { pool } from './pool.js';
const client=await pool.connect(); try { await client.query('BEGIN');
const pass=await bcrypt.hash('ChangeMe123!',12); await client.query(`INSERT INTO users(name,email,password_hash,role) VALUES('MarketHub Admin','admin@markethub.local',$1,'admin') ON CONFLICT(email) DO NOTHING`,[pass]);
const cats=['อิเล็กทรอนิกส์','แฟชั่น','บ้านและไลฟ์สไตล์']; for(const c of cats) await client.query('INSERT INTO categories(name) VALUES($1) ON CONFLICT(name) DO NOTHING',[c]);
const rows=await client.query('SELECT id,name FROM categories'); const cid=Object.fromEntries(rows.rows.map(x=>[x.name,x.id]));
const products=[['หูฟังไร้สาย Pro','อิเล็กทรอนิกส์',1290,30,'🎧'],['สมาร์ทวอทช์ Active','อิเล็กทรอนิกส์',2490,20,'⌚'],['รองเท้า Street Run','แฟชั่น',1890,25,'👟'],['เก้าอี้ Minimal','บ้านและไลฟ์สไตล์',3290,12,'🪑'],['คีย์บอร์ด Mechanical','อิเล็กทรอนิกส์',1590,40,'⌨️'],['กระเป๋า Everyday','แฟชั่น',990,35,'👜']];
for(const [name,cat,price,stock,img] of products) await client.query('INSERT INTO products(category_id,name,description,price,stock,image_url) SELECT $1,$2,$3,$4,$5,$6 WHERE NOT EXISTS(SELECT 1 FROM products WHERE name=$2)',[cid[cat],name,`สินค้า ${name} คุณภาพสำหรับ Marketplace`,price,stock,img]);
await client.query('COMMIT'); console.log('Seed complete. Admin: admin@markethub.local / ChangeMe123!'); } catch(e){await client.query('ROLLBACK'); console.error(e); process.exitCode=1;} finally {client.release(); await pool.end();}
