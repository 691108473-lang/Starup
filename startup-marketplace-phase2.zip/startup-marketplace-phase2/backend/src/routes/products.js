import {Router} from "express";
import {z} from "zod";
import {query} from "../db/pool.js";
import {requireAuth,requireRoles} from "../middleware/auth.js";
const router=Router();
const product=z.object({name:z.string().min(1).max(200),description:z.string().default(""),price:z.coerce.number().min(0),stock:z.coerce.number().int().min(0),category_id:z.string().uuid().nullable().optional(),image_url:z.string().url().nullable().optional(),status:z.enum(["active","draft","archived"]).default("active")});
router.get("/",async(req,res,next)=>{try{
 const q=String(req.query.q||"").trim(), cat=String(req.query.category||"").trim(); const p=[];const w=["p.status='active'"];
 if(q){p.push(`%${q}%`);w.push(`(p.name ILIKE $${p.length} OR p.description ILIKE $${p.length})`)}
 if(cat){p.push(cat);w.push(`c.name=$${p.length}`)}
 p.push(Math.min(Number(req.query.limit)||24,100));
 const r=await query(`SELECT p.id,p.name,p.description,p.price,p.stock,p.image_url,c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE ${w.join(" AND ")} ORDER BY p.created_at DESC LIMIT $${p.length}`,p);
 res.json({success:true,data:r.rows,message:"โหลดสินค้าสำเร็จ"});
}catch(e){next(e)}});
router.get("/:id",async(req,res,next)=>{try{const r=await query(`SELECT p.*,c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=$1`,[req.params.id]);if(!r.rowCount)return res.status(404).json({success:false,error:{code:"PRODUCT_NOT_FOUND",message:"ไม่พบสินค้า"}});res.json({success:true,data:r.rows[0],message:"สำเร็จ"})}catch(e){next(e)}});
router.post("/",requireAuth,requireRoles("staff","admin","super_admin"),async(req,res,next)=>{try{const d=product.parse(req.body);const r=await query(`INSERT INTO products(name,description,price,stock,category_id,image_url,status,seller_id) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,[d.name,d.description,d.price,d.stock,d.category_id||null,d.image_url||null,d.status,req.user.sub]);res.status(201).json({success:true,data:r.rows[0],message:"เพิ่มสินค้าสำเร็จ"})}catch(e){next(e)}});
router.put("/:id",requireAuth,requireRoles("staff","admin","super_admin"),async(req,res,next)=>{try{const d=product.partial().parse(req.body);const r=await query(`UPDATE products SET name=COALESCE($1,name),description=COALESCE($2,description),price=COALESCE($3,price),stock=COALESCE($4,stock),category_id=COALESCE($5,category_id),image_url=COALESCE($6,image_url),status=COALESCE($7,status),updated_at=NOW() WHERE id=$8 RETURNING *`,[d.name??null,d.description??null,d.price??null,d.stock??null,d.category_id??null,d.image_url??null,d.status??null,req.params.id]);if(!r.rowCount)return res.status(404).json({success:false,error:{code:"PRODUCT_NOT_FOUND",message:"ไม่พบสินค้า"}});res.json({success:true,data:r.rows[0],message:"แก้ไขสินค้าสำเร็จ"})}catch(e){next(e)}});
router.delete("/:id",requireAuth,requireRoles("admin","super_admin"),async(req,res,next)=>{try{const r=await query("UPDATE products SET status='archived',updated_at=NOW() WHERE id=$1 RETURNING id",[req.params.id]);if(!r.rowCount)return res.status(404).json({success:false,error:{code:"PRODUCT_NOT_FOUND",message:"ไม่พบสินค้า"}});res.json({success:true,data:r.rows[0],message:"เก็บสินค้าเข้าคลังแล้ว"})}catch(e){next(e)}});
export default router;
