import {Router} from "express";
import {pool,query} from "../db/pool.js";
import {requireAuth,requireRoles} from "../middleware/auth.js";
const router=Router();
router.get("/",requireAuth,async(req,res,next)=>{try{const r=await query("SELECT id,status,total,created_at FROM orders WHERE user_id=$1 ORDER BY created_at DESC",[req.user.sub]);res.json({success:true,data:r.rows,message:"โหลดออเดอร์สำเร็จ"})}catch(e){next(e)}});
router.get("/:id",requireAuth,async(req,res,next)=>{try{const r=await query(`SELECT o.*,json_agg(json_build_object('product_id',oi.product_id,'qty',oi.qty,'price',oi.price)) items FROM orders o LEFT JOIN order_items oi ON oi.order_id=o.id WHERE o.id=$1 AND o.user_id=$2 GROUP BY o.id`,[req.params.id,req.user.sub]);if(!r.rowCount)return res.status(404).json({success:false,error:{code:"ORDER_NOT_FOUND",message:"ไม่พบคำสั่งซื้อ"}});res.json({success:true,data:r.rows[0],message:"สำเร็จ"})}catch(e){next(e)}});
router.post("/",requireAuth,async(req,res,next)=>{const c=await pool.connect();try{
 await c.query("BEGIN");const cart=await c.query(`SELECT c.product_id,c.qty,p.name,p.price,p.stock FROM carts c JOIN products p ON p.id=c.product_id WHERE c.user_id=$1 FOR UPDATE`,[req.user.sub]);
 if(!cart.rowCount){await c.query("ROLLBACK");return res.status(400).json({success:false,error:{code:"EMPTY_CART",message:"ตะกร้าว่าง"}})}
 for(const x of cart.rows)if(x.qty>x.stock){await c.query("ROLLBACK");return res.status(409).json({success:false,error:{code:"OUT_OF_STOCK",message:`สินค้า ${x.name} มีไม่เพียงพอ`}})}
 const total=cart.rows.reduce((s,x)=>s+Number(x.price)*x.qty,0);const o=await c.query("INSERT INTO orders(user_id,status,total) VALUES($1,'pending',$2) RETURNING *",[req.user.sub,total]);
 for(const x of cart.rows){await c.query("INSERT INTO order_items(order_id,product_id,qty,price) VALUES($1,$2,$3,$4)",[o.rows[0].id,x.product_id,x.qty,x.price]);await c.query("UPDATE products SET stock=stock-$1,updated_at=NOW() WHERE id=$2",[x.qty,x.product_id])}
 await c.query("DELETE FROM carts WHERE user_id=$1",[req.user.sub]);await c.query("COMMIT");res.status(201).json({success:true,data:o.rows[0],message:"สร้างคำสั่งซื้อสำเร็จ"});
}catch(e){await c.query("ROLLBACK");next(e)}finally{c.release()}});
router.put("/:id/status",requireAuth,requireRoles("staff","admin","super_admin"),async(req,res,next)=>{try{
 const allowed=["pending","paid","processing","shipped","delivered","cancelled"];if(!allowed.includes(req.body.status))return res.status(400).json({success:false,error:{code:"INVALID_STATUS",message:"สถานะไม่ถูกต้อง"}});
 const r=await query("UPDATE orders SET status=$1,updated_at=NOW() WHERE id=$2 RETURNING *",[req.body.status,req.params.id]);if(!r.rowCount)return res.status(404).json({success:false,error:{code:"ORDER_NOT_FOUND",message:"ไม่พบคำสั่งซื้อ"}});res.json({success:true,data:r.rows[0],message:"อัปเดตสถานะสำเร็จ"});
}catch(e){next(e)}});
export default router;
