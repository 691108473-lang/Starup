import {Router} from "express";
import {z} from "zod";
import {query} from "../db/pool.js";
import {requireAuth} from "../middleware/auth.js";
const router=Router();
router.get("/",requireAuth,async(req,res,next)=>{try{
 const r=await query(`SELECT c.product_id,c.qty,p.name,p.price,p.stock,p.image_url,(c.qty*p.price) subtotal FROM carts c JOIN products p ON p.id=c.product_id WHERE c.user_id=$1 ORDER BY c.updated_at DESC`,[req.user.sub]);
 const total=r.rows.reduce((s,x)=>s+Number(x.subtotal),0);
 res.json({success:true,data:{items:r.rows,total},message:"โหลดตะกร้าสำเร็จ"});
}catch(e){next(e)}});
router.post("/",requireAuth,async(req,res,next)=>{try{
 const d=z.object({product_id:z.string().uuid(),qty:z.coerce.number().int().min(1)}).parse(req.body);
 const p=await query("SELECT stock FROM products WHERE id=$1 AND status='active'",[d.product_id]);
 if(!p.rowCount)return res.status(404).json({success:false,error:{code:"PRODUCT_NOT_FOUND",message:"ไม่พบสินค้า"}});
 if(d.qty>p.rows[0].stock)return res.status(409).json({success:false,error:{code:"OUT_OF_STOCK",message:"จำนวนสินค้าไม่เพียงพอ"}});
 await query(`INSERT INTO carts(user_id,product_id,qty) VALUES($1,$2,$3) ON CONFLICT(user_id,product_id) DO UPDATE SET qty=carts.qty+EXCLUDED.qty,updated_at=NOW()`,[req.user.sub,d.product_id,d.qty]);
 res.status(201).json({success:true,data:null,message:"เพิ่มลงตะกร้าสำเร็จ"});
}catch(e){next(e)}});
router.put("/:productId",requireAuth,async(req,res,next)=>{try{
 const qty=z.coerce.number().int().min(1).parse(req.body.qty);
 await query("UPDATE carts SET qty=$1,updated_at=NOW() WHERE user_id=$2 AND product_id=$3",[qty,req.user.sub,req.params.productId]);
 res.json({success:true,data:null,message:"อัปเดตตะกร้าสำเร็จ"});
}catch(e){next(e)}});
router.delete("/:productId",requireAuth,async(req,res,next)=>{try{await query("DELETE FROM carts WHERE user_id=$1 AND product_id=$2",[req.user.sub,req.params.productId]);res.json({success:true,data:null,message:"ลบสินค้าออกจากตะกร้าสำเร็จ"})}catch(e){next(e)}});
export default router;
