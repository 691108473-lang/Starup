import {Router} from "express";
import {query} from "../db/pool.js";
import {requireAuth,requireRoles} from "../middleware/auth.js";
const router=Router();const admin= requireRoles("staff","admin","super_admin");
router.get("/dashboard",requireAuth,admin,async(req,res,next)=>{try{
 const [u,o,r,p]=await Promise.all([query("SELECT COUNT(*)::int count FROM users"),query("SELECT COUNT(*)::int count FROM orders"),query("SELECT COALESCE(SUM(total),0)::numeric total FROM orders WHERE status IN('paid','processing','shipped','delivered')"),query("SELECT COUNT(*)::int count FROM products WHERE status='active'")]);
 res.json({success:true,data:{totalUsers:u.rows[0].count,totalOrders:o.rows[0].count,revenue:r.rows[0].total,activeProducts:p.rows[0].count},message:"โหลด Dashboard สำเร็จ"});
}catch(e){next(e)}});
router.get("/users",requireAuth,admin,async(req,res,next)=>{try{const r=await query("SELECT id,email,username,name,role,is_active,created_at FROM users ORDER BY created_at DESC LIMIT 200");res.json({success:true,data:r.rows,message:"โหลดผู้ใช้สำเร็จ"})}catch(e){next(e)}});
router.get("/orders",requireAuth,admin,async(req,res,next)=>{try{const r=await query("SELECT o.*,u.email,u.name FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.created_at DESC LIMIT 200");res.json({success:true,data:r.rows,message:"โหลดออเดอร์สำเร็จ"})}catch(e){next(e)}});
router.get("/products",requireAuth,admin,async(req,res,next)=>{try{const r=await query("SELECT p.*,c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id ORDER BY p.created_at DESC LIMIT 200");res.json({success:true,data:r.rows,message:"โหลดสินค้าสำเร็จ"})}catch(e){next(e)}});
export default router;
