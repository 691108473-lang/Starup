import {Router} from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import {z} from "zod";
import {query} from "../db/pool.js";
const router=Router();
const register=z.object({email:z.string().email(),username:z.string().min(3).max(80).optional(),password:z.string().min(8),name:z.string().min(1).max(160)});
const sign=u=>jwt.sign({sub:u.id,email:u.email,role:u.role,name:u.name},process.env.JWT_SECRET,{expiresIn:process.env.JWT_EXPIRES_IN||"1h"});
router.post("/register",async(req,res,next)=>{try{
 const d=register.parse(req.body); const exists=await query("SELECT id FROM users WHERE email=$1",[d.email]);
 if(exists.rowCount)return res.status(409).json({success:false,error:{code:"EMAIL_EXISTS",message:"อีเมลนี้ถูกใช้งานแล้ว"}});
 const hash=await bcrypt.hash(d.password,12);
 const r=await query(`INSERT INTO users(email,username,password_hash,name) VALUES($1,$2,$3,$4) RETURNING id,email,username,name,role`,[d.email,d.username||null,hash,d.name]);
 res.status(201).json({success:true,data:{user:r.rows[0],token:sign(r.rows[0])},message:"สมัครสมาชิกสำเร็จ"});
}catch(e){next(e)}});
router.post("/login",async(req,res,next)=>{try{
 const d=z.object({email:z.string().email(),password:z.string().min(1)}).parse(req.body);
 const r=await query("SELECT id,email,name,role,password_hash,is_active FROM users WHERE email=$1",[d.email]);
 if(!r.rowCount||!r.rows[0].is_active)return res.status(401).json({success:false,error:{code:"INVALID_CREDENTIALS",message:"อีเมลหรือรหัสผ่านไม่ถูกต้อง"}});
 const u=r.rows[0]; if(!await bcrypt.compare(d.password,u.password_hash||""))return res.status(401).json({success:false,error:{code:"INVALID_CREDENTIALS",message:"อีเมลหรือรหัสผ่านไม่ถูกต้อง"}});
 delete u.password_hash;res.json({success:true,data:{user:u,token:sign(u)},message:"เข้าสู่ระบบสำเร็จ"});
}catch(e){next(e)}});
router.get("/google",(req,res)=>res.status(501).json({success:false,error:{code:"GOOGLE_OAUTH_NOT_CONFIGURED",message:"ต้องตั้งค่า Google OAuth ก่อนใช้งาน"}}));
router.get("/google/callback",(req,res)=>res.status(501).json({success:false,error:{code:"GOOGLE_OAUTH_NOT_CONFIGURED",message:"Google OAuth callback ยังไม่ได้เปิดใช้งาน"}}));
export default router;
