import fs from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";
import {pool} from "./pool.js";
const dir=path.dirname(fileURLToPath(import.meta.url));
await pool.query(fs.readFileSync(path.join(dir,"schema.sql"),"utf8"));
await pool.end();
console.log("Schema ready");
