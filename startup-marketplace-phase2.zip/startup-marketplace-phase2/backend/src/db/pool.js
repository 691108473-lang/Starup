import pg from "pg";
import "dotenv/config";
const { Pool } = pg;
export const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 10 });
export const query = (text, params) => pool.query(text, params);
