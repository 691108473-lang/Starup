import {pool,query} from "./pool.js";
import bcrypt from "bcryptjs";
const adminHash=await bcrypt.hash("ChangeMe123!",12);
const u=await query(`INSERT INTO users(email,username,password_hash,name,role) VALUES
('admin@markethub.local','admin',$1,'MarketHub Admin','admin')
ON CONFLICT(email) DO UPDATE SET role='admin' RETURNING id`,[adminHash]);
for(const name of ["อิเล็กทรอนิกส์","แฟชั่น","บ้านและไลฟ์สไตล์"])
 await query("INSERT INTO categories(name) VALUES($1) ON CONFLICT(name) DO NOTHING",[name]);
const cats=await query("SELECT id,name FROM categories");
const map=Object.fromEntries(cats.rows.map(x=>[x.name,x.id]));
const products=[
["หูฟังไร้สาย Pro","เสียงคมชัด ใช้งานได้ทุกวัน",1290,25,map["อิเล็กทรอนิกส์"]],
["สมาร์ทวอทช์ Active","ติดตามกิจกรรมและการแจ้งเตือน",2490,18,map["อิเล็กทรอนิกส์"]],
["รองเท้า Everyday","รองเท้าสไตล์มินิมอล",1890,30,map["แฟชั่น"]],
["เก้าอี้ทำงาน Comfort","รองรับการทำงานระยะยาว",3590,12,map["บ้านและไลฟ์สไตล์"]]
];
for(const p of products) await query(`INSERT INTO products(name,description,price,stock,category_id,status) VALUES($1,$2,$3,$4,$5,'active')`,p);
await pool.end();
console.log("Seed ready. Demo admin: admin@markethub.local / ChangeMe123!");
