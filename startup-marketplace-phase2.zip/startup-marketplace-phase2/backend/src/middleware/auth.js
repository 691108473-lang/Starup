import jwt from "jsonwebtoken";
export function requireAuth(req,res,next){
 const h=req.headers.authorization; const token=h?.startsWith("Bearer ")?h.slice(7):null;
 if(!token)return res.status(401).json({success:false,error:{code:"UNAUTHORIZED",message:"กรุณาเข้าสู่ระบบ"}});
 try{req.user=jwt.verify(token,process.env.JWT_SECRET);next()}
 catch{return res.status(401).json({success:false,error:{code:"INVALID_TOKEN",message:"เซสชันไม่ถูกต้องหรือหมดอายุ"}})}
}
export function requireRoles(...roles){return(req,res,next)=>{
 if(!req.user||!roles.includes(req.user.role))return res.status(403).json({success:false,error:{code:"FORBIDDEN",message:"ไม่มีสิทธิ์ดำเนินการ"}});
 next();
}}
