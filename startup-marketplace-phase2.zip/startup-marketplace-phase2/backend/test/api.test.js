import test from "node:test";
import assert from "node:assert/strict";

test("API response contract should use success/data/error shape",()=>{
 const success={success:true,data:{},message:"ok"};
 const error={success:false,error:{code:"INVALID_REQUEST",message:"bad"}};
 assert.equal(success.success,true); assert.ok("data" in success);
 assert.equal(error.success,false); assert.ok("error" in error);
});
test("Order statuses are restricted",()=>{
 const allowed=["pending","paid","processing","shipped","delivered","cancelled"];
 assert.equal(allowed.includes("unknown"),false);
 assert.equal(allowed.includes("paid"),true);
});
