| ID | Module | Input | Expected |
|---|---|---|---|
| TC001 | Login | valid email/password | token returned |
| TC002 | Login | wrong password | 401 |
| TC003 | Register | duplicate email | 409 |
| TC004 | Products | search query | matching products |
| TC005 | Cart | valid product + qty | item added |
| TC006 | Cart | qty > stock | 409 |
| TC007 | Order | empty cart | 400 |
| TC008 | Order | valid cart | order created |
| TC009 | Admin | no/invalid token | 401/403 |
| TC010 | Admin | valid admin token | dashboard returned |
| TC011 | Security | invalid role | 403 |
| TC012 | Health | GET /api/health | status ok |
