# API Overview

## Public
- GET `/api/health`
- POST `/api/auth/register`
- POST `/api/auth/login`
- GET `/api/products`
- GET `/api/products/:id`

## Authenticated User
- GET `/api/cart`
- POST `/api/cart`
- PUT `/api/cart/:productId`
- DELETE `/api/cart/:productId`
- GET `/api/orders`
- GET `/api/orders/:id`
- POST `/api/orders`

## Staff/Admin
- POST/PUT/DELETE `/api/products`
- GET `/api/admin/dashboard`
- GET `/api/admin/users`
- GET `/api/admin/orders`
- GET `/api/admin/products`
- PUT `/api/orders/:id/status`

All JSON responses use the project's `success/data/message` or `success/error` contract.
