const API="http://localhost:4000/api";let category="";
const grid=document.querySelector("#grid");
const money=v=>Number(v).toLocaleString("th-TH",{style:"currency",currency:"THB"});
async function load(){grid.innerHTML="กำลังโหลด...";const q=encodeURIComponent(document.querySelector("#search").value);try{
 const r=await fetch(`${API}/products?q=${q}&category=${encodeURIComponent(category)}`);const j=await r.json();if(!j.success)throw Error(j.error?.message);grid.innerHTML=j.data.map((p,i)=>`<article class="card"><div class="pic">${["🎧","⌚","👟","🪑"][i%4]}</div><div class="body"><small>${p.category||"สินค้า"}</small><h3>${safe(p.name)}</h3><div class="row"><b>${money(p.price)}</b><button class="add" data-id="${p.id}">เพิ่ม</button></div></div></article>`).join("");
 document.querySelectorAll(".add").forEach(b=>b.onclick=()=>alert("ต้องเข้าสู่ระบบก่อนเพิ่มสินค้าลงตะกร้า"));
}catch(e){grid.innerHTML=`เชื่อมต่อ API ไม่สำเร็จ: ${e.message}`}}
function safe(x){return String(x).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
document.querySelector("#search").onkeydown=e=>e.key==="Enter"&&load();
document.querySelectorAll(".chips button").forEach(b=>b.onclick=()=>{document.querySelectorAll(".chips button").forEach(x=>x.classList.remove("active"));b.classList.add("active");category=b.dataset.cat;load()});
const modal=document.querySelector("#modal");document.querySelector("#loginBtn").onclick=()=>modal.classList.remove("hidden");document.querySelector("#close").onclick=()=>modal.classList.add("hidden");
document.querySelector("#google").onclick=()=>document.querySelector("#msg").textContent="ตั้งค่า Google OAuth ใน backend ก่อนใช้งาน";
document.querySelector("#login").onsubmit=async e=>{e.preventDefault();try{const r=await fetch(`${API}/auth/login`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:email.value,password:password.value})});const j=await r.json();if(!j.success)throw Error(j.error?.message);localStorage.setItem("token",j.data.token);document.querySelector("#msg").textContent="เข้าสู่ระบบสำเร็จ";setTimeout(()=>modal.classList.add("hidden"),600)}catch(x){document.querySelector("#msg").textContent=x.message}};load();
