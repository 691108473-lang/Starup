# MarketHub Marketplace — Phase 2

ต่อยอดจาก Phase 1 โดยเพิ่ม:
- Product management API สำหรับ Staff/Admin
- Cart API: ดู/เพิ่ม/แก้ไข/ลบ
- Checkout จาก Cart
- Order detail
- Admin order management
- Admin product CRUD
- Admin dashboard
- Admin frontend
- Seed data
- Basic API tests
- Google OAuth configuration scaffold
- Security and validation improvements

## Run
1. `docker compose up -d postgres`
2. `cd backend`
3. `npm install`
4. copy `.env.example` → `.env`
5. `npm run db:init`
6. `npm run db:seed`
7. `npm run dev`
8. Serve `frontend/` and `admin/` with a local static server.

API: `http://localhost:4000/api`

The Google OAuth endpoints intentionally require real Google Cloud credentials before activation.
