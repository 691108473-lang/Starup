const API="http://localhost:4000/api";
const token=localStorage.getItem("token");
const headers=()=>({Authorization:`Bearer ${token}`});
async function load(){
 if(!token){alert("กรุณาเข้าสู่ระบบด้วยบัญชี Admin ก่อน");return}
 try{
  const [d,o,p]=await Promise.all([
   fetch(`${API}/admin/dashboard`,{headers:headers()}).then(r=>r.json()),
   fetch(`${API}/admin/orders`,{headers:headers()}).then(r=>r.json()),
   fetch(`${API}/admin/products`,{headers:headers()}).then(r=>r.json())
  ]);
  if(!d.success)throw Error(d.error?.message||"ไม่มีสิทธิ์");
  users.textContent=d.data.totalUsers;ordersCount.textContent=d.data.totalOrders;revenue.textContent=Number(d.data.revenue).toLocaleString("th-TH",{style:"currency",currency:"THB"});productsCount.textContent=d.data.activeProducts;
  ordersTable.innerHTML=(o.data||[]).map(x=>`<tr><td>${x.id.slice(0,8)}...</td><td>${safe(x.name)}<br><small>${safe(x.email)}</small></td><td>${Number(x.total).toLocaleString("th-TH")} ฿</td><td>${x.status}</td><td><button onclick="changeStatus('${x.id}','processing')">กำลังจัดส่ง</button></td></tr>`).join("");
  productsTable.innerHTML=(p.data||[]).map(x=>`<tr><td>${safe(x.name)}</td><td>${Number(x.price).toLocaleString("th-TH")} ฿</td><td>${x.stock}</td><td>${x.status}</td></tr>`).join("");
 }catch(e){alert(e.message)}
}
async function changeStatus(id,status){const r=await fetch(`${API}/orders/${id}/status`,{method:"PUT",headers:{"Content-Type":"application/json",...headers()},body:JSON.stringify({status})});const j=await r.json();if(!j.success)alert(j.error?.message);load()}
function safe(x){return String(x).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
refresh.onclick=load;load();
